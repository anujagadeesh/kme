<div id="gallery" class="sidebar-header">
    Gallery
    <div class="see-all">View All</div>
</div>

<div id="sidebargallery">
    <ul>
        <li>
            <img src="<?php echo IMG_PATH; ?>sidebar_gallery_1.jpg">
            <div class="description">Lorem ipsum dolor sit amet</div>
            <br class="clear"/>
            <span class="venue">Venue: New York City, NY</span>
            <span class="date">October 14</span>
        </li>
        <li>
            <img src="<?php echo IMG_PATH; ?>sidebar_gallery_2.jpg">
            <div class="description">Lorem ipsum dolor sit amet</div>
            <br class="clear"/>
            <span class="venue">Venue: San Francisco, CA</span>
            <span class="date">October 18</span>
        </li>
        <li>
            <img src="<?php echo IMG_PATH; ?>sidebar_gallery_3.jpg">
            <div class="description">Lorem ipsum dolor sit amet</span>
                <br class="clear"/>
                <span class="venue">Venue: Chicago, IL</span>
                <span class="date">October 24</span>
        </li>
    </ul>
</div>



