<?php
	$content = '<div class="cause_sup_np_info center">'.elgg_echo('event:closed').'</div>';
	echo elgg_view_module('aside', elgg_echo('event:buyTicket'), $content);
?>
