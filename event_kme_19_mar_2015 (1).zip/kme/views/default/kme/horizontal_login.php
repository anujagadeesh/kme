<div id="login" class="section">
    <form class = "h_login">
      <ul>  
        <li class = "h_username">
            <input id="username" class = "Value" value="username" type = "text" />
        </li>
        <li class = "h_username">
            <input id="password" class = "Value" value="username" type = "password" />
        </li>
        <li class = "Login">
          <input class="Login" type="button" value="LOG IN"/>
        </li>
        <li class = "Login">
            <a class="ForgotPassword" href="#" title ="Problems signing in?">?</a>
        </li>
    </ul>
    </form>
</div>