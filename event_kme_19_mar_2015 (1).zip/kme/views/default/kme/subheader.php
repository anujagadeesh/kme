	<div class="elgg-col-2of3 fleft">
		<?php echo elgg_view_menu('site'); ?>
	</div>
	<div class="elgg-col-1of3 fright">
		<?php echo elgg_view_menu('right');?>
	</div>